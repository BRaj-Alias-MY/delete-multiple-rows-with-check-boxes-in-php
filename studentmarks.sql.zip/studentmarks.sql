-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 13, 2016 at 09:51 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `students`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `studentmarks`
-- 

CREATE TABLE `studentmarks` (
  `id` int(100) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `maths` int(100) NOT NULL,
  `physics` int(100) NOT NULL,
  `computers` int(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

-- 
-- Dumping data for table `studentmarks`
-- 

INSERT INTO `studentmarks` VALUES (1, 'Sekhar', 90, 85, 93);
INSERT INTO `studentmarks` VALUES (6, 'Naresh', 92, 85, 66);
INSERT INTO `studentmarks` VALUES (19, 'Muraly', 63, 69, 88);
INSERT INTO `studentmarks` VALUES (20, 'Naresh', 92, 85, 66);
INSERT INTO `studentmarks` VALUES (21, 'Muraly', 63, 69, 88);
INSERT INTO `studentmarks` VALUES (22, 'Naresh', 92, 85, 66);
INSERT INTO `studentmarks` VALUES (23, 'Muraly', 63, 69, 88);
INSERT INTO `studentmarks` VALUES (24, 'Naresh', 92, 85, 66);
INSERT INTO `studentmarks` VALUES (33, 'Muraly', 63, 69, 88);
INSERT INTO `studentmarks` VALUES (34, 'Naresh', 92, 85, 66);
